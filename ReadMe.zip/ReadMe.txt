필요 가상환경 파이썬 버전
3.8.1 // conda create -n 가상환경이름 python==3.8.1

필요 라이브러리
1. 넘파이
2. 판다스
3. 싸이킷런 
4. 텐서플로우 // pip install tensorflow
6. openpyxl // pip install openpyxl
7. pyqt5 // pip install pyqt5
8. konlpy // pip install konlpy